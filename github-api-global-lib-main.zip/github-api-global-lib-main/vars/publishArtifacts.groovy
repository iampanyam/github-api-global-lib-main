def call(Map config) {
    echo 'inside publishArtifacts'
}