def call(Map config=[:]) {
  echo getPullRequestInfoInternal(config)
}
