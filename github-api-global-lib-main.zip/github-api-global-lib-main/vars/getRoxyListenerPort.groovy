def call() {
  return Math.abs(new Random().nextInt() % 500) + 65000  
}